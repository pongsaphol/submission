int HC(int N);
