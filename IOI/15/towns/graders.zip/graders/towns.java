public class towns {
	int hubDistance(int N, int sub) {
		int R = grader.lib.getDistance(0,1);
		return R;
	}
}
