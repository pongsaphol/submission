#ifndef towns_h
#define towns_h

int getDistance(int i, int j);
int hubDistance(int N, int sub);

#endif
