#include "wiring.h"

long long min_total_length(std::vector<int> r, std::vector<int> b) {
	return 0;
}
