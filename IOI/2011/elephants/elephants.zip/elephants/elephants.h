void init(int N, int L, int X[]);
int update(int i, int y);
