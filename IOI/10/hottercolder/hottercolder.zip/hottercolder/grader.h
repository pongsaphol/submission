int Guess(int G);
