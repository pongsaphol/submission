#include "towns.h"

int hubDistance(int N, int sub) {
	int R = getDistance(0,1);
	return R;
}
