public class wiring {

	long min_total_length(int[] r, int[] b) {
		return 0;
	}
}

