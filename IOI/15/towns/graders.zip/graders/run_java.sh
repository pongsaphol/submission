#!/bin/bash

problem=towns

java -jar -Xmx512M -Xss64M $problem.jar
