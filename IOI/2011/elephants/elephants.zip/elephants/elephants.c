#include "elephants.h"

int n;

void init(int N, int L, int X[])
{
  n = N;
}

int update(int i, int y)
{
  return n;
}
